﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_6
{
    class Program
    {
        static void Main(string[] args)
        {
            Random aleatoire1 = new Random();
            Random aleatoire2 = new Random();
            int nbre_calcule1;
            int nbre_calcule2;
            int resultat;
            string nbre_ques_demande;
            string reponse;
            int nbre_reponse_vrai=0;
            int num_question = 0;
            int valeur_reponse;
            int valeur_nbre_ques_demande;

            Console.Write("Combien de question voulez vous : ");
            nbre_ques_demande = Console.ReadLine();
            Console.WriteLine("");

            if (int.TryParse(nbre_ques_demande, out valeur_nbre_ques_demande)) 
            {
                do
                {
                    nbre_calcule1 = aleatoire1.Next(0, 10);
                    nbre_calcule2 = aleatoire2.Next(0, 20);
                    resultat = nbre_calcule1 + nbre_calcule2;

                    Console.Write("Que vaut : "+nbre_calcule1+" + "+nbre_calcule2+" = ");
                    reponse=Console.ReadLine();

                    if (int.TryParse(reponse,out valeur_reponse))
                    {
                        if (valeur_reponse == resultat)
                        {
                            nbre_reponse_vrai += 1;
                            num_question += 1;

                            Console.WriteLine("Bonne reponse !!!");
                            Console.WriteLine("");
                            Console.WriteLine("Vous venez de repondre a la question " + num_question + " / " + valeur_nbre_ques_demande);
                            Console.WriteLine("");
                        }

                        else
                        {
                            num_question += 1;
                            Console.WriteLine("Mauvaise reponse !!! ");
                            Console.WriteLine("");
                            Console.WriteLine("Vous venez de repondre a la question " + num_question + " / " + valeur_nbre_ques_demande);
                            Console.WriteLine("");
                        }
                   
                    }
                } while ( num_question<valeur_nbre_ques_demande);

                Console.WriteLine("Nombre de bonne reponse : " + nbre_reponse_vrai);
            }

            else
            {
            }
            

        }
    }
}
