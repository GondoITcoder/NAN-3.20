﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Création
            List<int> maListe = new List<int>();
            string choix;
            int som = 0;

            do
            {
                //Menu
                Console.WriteLine("##############################################");
                Console.WriteLine("####          1- ENTRER DES PRIX          ####");
                Console.WriteLine("####          2- C'EST FINI               ####");
                Console.WriteLine("##############################################");
                Console.WriteLine("");

                //Saisi au clavier du choix
                Console.Write("ENTREZ VOTRE CHOIX : ");
                choix = Console.ReadLine();

                if (choix == "1")
                {
                    //Saisi au clavier du prix
                    Console.WriteLine("");
                    Console.Write("ENTREZ UN PRIX SANS LE CFA : ");

                    //recuperation au clavier du prix
                    string prix_entrer;
                    prix_entrer = Console.ReadLine();
                    Console.WriteLine("");

                    //Conversion du prix en entier
                    int valeur;
                    if (int.TryParse(prix_entrer, out valeur))
                    {
                        // Ajout du prix dans la liste
                        maListe.Add(valeur);
                    }

                    else
                    {
                        Console.WriteLine("ERREUR! Veuillez entrer un entier");
                        Console.WriteLine("ENTREZ UN PRIX SANS LE CFA : ");
                        prix_entrer = Console.ReadLine();
                        Console.WriteLine("");
                        continue;
                    }
                }
                else if (choix == "2")
                {
                    Console.WriteLine("");
                    Console.Write("VOICI LES PRIX QUE VOUS AVEZ ENTTRER EN FRCFA : ");
                    // Parcourir la liste avec for
                    foreach (int elt in maListe)
                    {
                        som+=elt;
                        Console.Write(" | " + elt);  
                    }
                    break;
                }

                else {
                    Console.WriteLine("");
                    Console.WriteLine("Choix inexistant dans le menu. Veuillez entrer soit 1 ou 2 pour faire votre choix");
                    Console.WriteLine("");
                }

            } while (choix != "2");

            Console.WriteLine("");
            Console.WriteLine("");

            Console.Write("VOICI LA SOMME DES PRIX : "+som+" fcfa");

            Console.WriteLine("");
            Console.WriteLine("");

        }
    }
}
