﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_3
{
    class Program
    {
        static void Main(string[] args)
        {
            const int NombreMagique = 5;
            int nbre_vie = 4;
            string nbre_entrer;
            int valeur;

            do
            {
                Console.Write("ENTRER UN NOMBRE : ");
                nbre_entrer = Console.ReadLine();
                Console.WriteLine("");

                if (int.TryParse(nbre_entrer, out valeur))
                {
                    if (valeur < NombreMagique)
                    {
                        nbre_vie -= 1;
                        Console.WriteLine("Ce nombre est trop petit");
                        Console.WriteLine("");
                    }

                    else if (valeur > NombreMagique)
                    {
                        nbre_vie -= 1;
                        Console.WriteLine("Ce nombre est trop grand");
                        Console.WriteLine("");
                    }

                    else
                    {
                        nbre_vie -= 1;
                        Console.WriteLine("BRAVO !!!!!!!!! VOUS AVEZ TROUVER LE NOMBRE MAGIQUE");
                        Console.WriteLine("");
                        Console.WriteLine("CE NOMBRE EST : " + NombreMagique);
                        Console.WriteLine("");
                        break;
                    }
                }

                else
                {
                    nbre_vie -= 1;
                    Console.WriteLine("ERREUR ! Veuillez entrer un entier.");
                    Console.WriteLine("");
                }

                if(nbre_vie==0){
                    Console.WriteLine("VOUS AVEZ PERDU ????.");
                    Console.WriteLine("");
                    break;
                }


            } while (valeur != NombreMagique || nbre_vie>0);
        }
    }
}
