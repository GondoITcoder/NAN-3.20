﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_2
{
    class Program
    {
        static void Main(string[] args)
        {
            const int NombreMagique=5;
            string nbre_entrer;
            int valeur;

                Console.Write("ENTRER UN NOMBRE : ");
                nbre_entrer=Console.ReadLine();
                Console.WriteLine("");

                if (int.TryParse(nbre_entrer, out valeur))
                {
                    if (valeur < NombreMagique)
                    {
                        Console.WriteLine("Ce nombre est trop petit");
                        Console.WriteLine("");
                    }

                    else if (valeur > NombreMagique)
                    {
                        Console.WriteLine("Ce nombre est trop grand");
                        Console.WriteLine("");
                    }

                    else
                    {
                        Console.WriteLine("BRAVO !!!!!!!! VOUS AVEZ TROUVER LE NOMBRE MAGIQUE");
                        Console.WriteLine("");
                        Console.WriteLine("CE NOMBRE EST : "+NombreMagique);
                        Console.WriteLine("");
                    }
                }

                else
                {
                    Console.WriteLine("ERREUR ! Veuillez entrer un entier.");
                    Console.WriteLine("");
                }
        }
    }
}
