﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_5
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> maliste = new List<int>();
            int result=1;
            maliste.Add(100); maliste.Add(300); maliste.Add(700); maliste.Add(100+1);
            maliste.Add(4 % 4); maliste.Add(100/100); maliste.Add(2 - 2); maliste.Add(3*1);

            foreach(int elt in maliste)
            {
                result *= elt;
            }

            Console.WriteLine("Le totale des nombres est : "+result);
        }
    }
}
