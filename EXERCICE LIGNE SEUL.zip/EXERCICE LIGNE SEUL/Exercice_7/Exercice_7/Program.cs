﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_7
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] montableau = {100, 200, 700, 100+1, 4%4, 100/100, 2-2, 3*1};
            int somme=0;

            foreach (int item in montableau )
            {
                Console.Write("| "+item);
                somme =somme+item;
            }

            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("la somme est : "+somme);
            Console.WriteLine("");
            Console.WriteLine("");
        }
    }
}
