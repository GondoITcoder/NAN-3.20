﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Random aleatoire=new Random();
            int NombreMagique = aleatoire.Next(3, 10);
            int nbre_vie = 4;
            string nbre_entrer;
            int valeur;

            do
            {
                Console.Write("ENTRER UN NOMBRE : ");
                nbre_entrer = Console.ReadLine();
                Console.WriteLine("");

                if (int.TryParse(nbre_entrer, out valeur))
                {
                    if (valeur < 3 || valeur > 10)
                    {
                        Console.WriteLine("");
                        Console.WriteLine("VOUS DEVEZ ENTRER UN NOMBRE COMPRIS ENTRE 3 ET 10");
                        Console.WriteLine("");
                        continue;
                    }
                    else{
                        if (valeur < NombreMagique)
                        {
                            nbre_vie -= 1;
                            Console.WriteLine("Ce nombre est trop petit");
                            Console.WriteLine("");
                        }

                        else if (valeur > NombreMagique)
                        {
                            nbre_vie -= 1;
                            Console.WriteLine("Ce nombre est trop grand");
                            Console.WriteLine("");
                        }

                        else
                        {
                            nbre_vie -= 1;
                            Console.WriteLine("BRAVO !!!!!!!!! VOUS AVEZ TROUVER LE NOMBRE MAGIQUE");
                            Console.WriteLine("");
                            Console.WriteLine("CE NOMBRE EST : " + NombreMagique);
                            Console.WriteLine("");
                            break;
                        }
                    }
                }

                else
                {
                    nbre_vie -= 1;
                    Console.WriteLine("ERREUR ! Veuillez entrer un entier.");
                    Console.WriteLine("");
                }

                if (nbre_vie == 0)
                {
                    Console.WriteLine("VOUS AVEZ PERDU ????.");
                    Console.WriteLine("");
                    break;
                }


            } while (valeur != NombreMagique || nbre_vie > 0);
        }
    }
}
