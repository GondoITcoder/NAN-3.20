﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_4
{
    class Program
    {
        static void Main(string[] args)
        {
            double limite_vitesse, vitesse_voiture;
            int point_inapt=0;

            try
            {
                Console.Write("ENTREZ LA LIMITE DE VITESSE : ");
                limite_vitesse = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("");

                Console.Write("ENTREZ LA VITESSE D'UNE VOITURE : ");
                vitesse_voiture = Convert.ToDouble(Console.ReadLine());

                if (limite_vitesse > vitesse_voiture)
                {
                    Console.WriteLine("");
                    Console.WriteLine("OK");
                    Console.WriteLine("");
                }

                else
                {
                    double exces = vitesse_voiture - limite_vitesse;

                    for(int compteur=5; compteur<=exces; compteur+=5)
                    {
                        point_inapt++;
                    }

                    if(point_inapt<=12)
                    {
                        Console.WriteLine("");
                        Console.WriteLine("VOUS AVEZ "+point_inapt+" POINT(S) D'INAPTITUDE");
                        Console.WriteLine("");
                    }

                    else
                    {
                        Console.WriteLine("");
                        Console.WriteLine("LICENCE SUSPENDUE");
                        Console.WriteLine("");
                    }

                }
            }

            catch(Exception)
            {
                Console.WriteLine("");
                Console.WriteLine("ERREUR ??? VOUS DEVEZ ENTRER UN NOMBRE.");
                Console.WriteLine("");
            }
        }
    }
}
