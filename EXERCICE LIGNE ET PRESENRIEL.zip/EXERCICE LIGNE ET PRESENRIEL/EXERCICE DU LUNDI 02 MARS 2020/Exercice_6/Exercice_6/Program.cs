﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_6
{
    class Program
    {
        static void Main(string[] args)
        {
            string nom;
            Console.Write("ENTRER VOTRE NOM : ");
            nom = Console.ReadLine();

            char[] tableau=new char[nom.Length];
            for (int i = nom.Length; i > 0; i-- )
            {
                tableau[nom.Length - i] = nom[i - 1];
            }

            string nom_renverser=new string(tableau);
            Console.WriteLine("");
            Console.WriteLine("NOM RENVERSER : " + nom_renverser);
            Console.WriteLine("");
        }
    }
}
