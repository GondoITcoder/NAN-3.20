﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_3
{
    class Program
    {
        static void Main(string[] args)
        {
            double hauteur, largeur;
            try
            {
                Console.Write("ENTREZ LA HAUTEUR DE L'IMAGE : ");
                hauteur = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("");

                Console.Write("ENTREZ LA LARGEUR DE L'IMAGE : ");
                largeur = Convert.ToDouble(Console.ReadLine());

                if (hauteur > largeur)
                {
                    Console.WriteLine("");
                    Console.WriteLine("L'IMAGE EST PORTRAIT");
                    Console.WriteLine("");
                }

                else
                {
                    Console.WriteLine("");
                    Console.WriteLine("L'IMAGE EST PAYSAGE");
                    Console.WriteLine("");
                }
            }
            catch (Exception)
            {
                Console.WriteLine("");
                Console.WriteLine("ERREUR ??? VOUS DEVEZ ENTRER UN NOMBRE.");
                Console.WriteLine("");
            }
        }
    }
}
