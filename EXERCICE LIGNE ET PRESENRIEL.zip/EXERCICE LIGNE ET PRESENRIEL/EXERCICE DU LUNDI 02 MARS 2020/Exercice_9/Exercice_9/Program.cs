﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_9
{
    class Program
    {
        static void Main(string[] args)
        {
            string nombres;
            string[] mon_tableau = new string[] { };

            Console.WriteLine("######################################################################");
            Console.WriteLine("####                     CE PROGRAMME MARCHE                      ####");
            Console.WriteLine("####       MAIS UNIQUEMENT AVEC DES CHIFFRES ALLANT DE 0 A 9      ####");
            Console.WriteLine("####    EXEMPLE:<<<< 4,3,2,7,5,1 >>>> DONNE <<<< |1 |2 |3 >>>>    ####");
            Console.WriteLine("#######################################################################");
            Console.WriteLine("");

            try
            {
                do
                {
                    Console.Write("ENTRER VOTRE LISTE DE CHIFFRE : ");
                    nombres = Console.ReadLine();
                    mon_tableau = nombres.Split(',');

                    for (int i = 0; i < mon_tableau.Length; i++)
                    {
                        int liste = Convert.ToInt32(mon_tableau[i]);
                    }

                    Array.Sort(mon_tableau);//Permet de trier le tableau mon_tableau

                    if (mon_tableau.Length == 0 || mon_tableau.Length < 5)
                    {
                        Console.WriteLine("");
                        Console.WriteLine("LISTE NON VALIDE");
                        Console.WriteLine("");
                        Console.WriteLine("VEUILLEZ REESSAYEZ");
                        Console.WriteLine("");
                    }

                    else
                    {
                        Console.WriteLine("");
                        Console.WriteLine("LISTE VALIDE");
                        Console.WriteLine("");
                        Console.Write("LES 3 PLUS PETITS NOMBRES DE LA LISTE SONT: ");
                        Console.Write("| " + mon_tableau[0]);
                        Console.Write("| " + mon_tableau[1]);
                        Console.Write("| " + mon_tableau[2]);
                        Console.WriteLine("");
                        Console.WriteLine("");
                    }
                } while (mon_tableau.Length == 0 || mon_tableau.Length < 5);
            }
            catch (Exception)
            {
                Console.WriteLine("");
                Console.WriteLine("ERREUR ??? VOUS DEVEZ ENTRER DES NOMBRES SEPARER PAR DES VIRGULES.");
                Console.WriteLine("");
            }
        }
    }
}
