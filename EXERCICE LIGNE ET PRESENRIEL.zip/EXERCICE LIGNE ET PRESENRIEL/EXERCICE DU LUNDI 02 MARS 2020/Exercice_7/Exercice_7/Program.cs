﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_7
{
    class Program
    {
        static void Main(string[] args)
        {
            var nombres = new List<int>();
            string nombre_entrer;
            int compteur_nombre = 0;
            int valeur_nombre_entrer;

            while (nombres.Count < 5)
            {
                compteur_nombre++;
                Console.Write("ENTREZ LE NOMBRE {0} : ", compteur_nombre);
                nombre_entrer = Console.ReadLine();
                Console.WriteLine("");

                if (int.TryParse(nombre_entrer, out valeur_nombre_entrer))
                {

                    if (nombres.Contains(valeur_nombre_entrer))
                    {
                        Console.WriteLine("VOUS AVEZ DEJA ENTRER CE NOMBRE.");
                        Console.WriteLine("");
                        compteur_nombre--;
                    }
                    else
                        nombres.Add(valeur_nombre_entrer);
                }

                else
                {
                    Console.WriteLine("ERREUR ?? VOUS DEVEZ ENTRER UN NOMBRE.");
                    compteur_nombre--;
                    Console.WriteLine("");
                }
            }

            Console.Clear();//Permet d'effacer l'ecran de la console

            nombres.Sort();//Permet de trier la liste des nombres
            Console.WriteLine("");
            Console.Write("NOMBRE TRIER : ");
            foreach (var elt in nombres)
            {
                Console.Write("| "+elt);
            }
            Console.WriteLine("");
            Console.WriteLine("");
        }
    }
}
