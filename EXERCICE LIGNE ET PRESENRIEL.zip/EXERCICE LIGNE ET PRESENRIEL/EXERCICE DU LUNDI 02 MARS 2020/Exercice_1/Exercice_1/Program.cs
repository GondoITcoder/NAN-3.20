﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_1
{
    class Program
    {
        static void Main(string[] args)
        {
            string numero;
            int valeur_numero;

            Console.Write("ENTREZ UN NUMERO : ");
            numero = Console.ReadLine();

            if (int.TryParse(numero, out valeur_numero))
            {
                if (valeur_numero < 1 || valeur_numero > 10)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Invalide");
                    Console.WriteLine("");
                }

                else
                {
                    Console.WriteLine("");
                    Console.WriteLine("Valide");
                    Console.WriteLine("");
                }
            }

            else
            {
                Console.WriteLine("");
                Console.WriteLine("ERREUR ?? VOUS DEVEZ ENTRER UN ENTIER.");
                Console.WriteLine("");
            }
        }
    }
}
