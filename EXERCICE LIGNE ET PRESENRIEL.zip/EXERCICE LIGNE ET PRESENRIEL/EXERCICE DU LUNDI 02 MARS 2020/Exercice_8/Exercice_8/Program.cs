﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_8
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> nombres = new List<int>();
            List<int> nombres_unique = new List<int>();
            string valeur_entrer;
            int compteur_numero=0;
            try
            {

                do
                {
                    Console.Clear();
                    Console.WriteLine("################################################################################");
                    Console.WriteLine("####                               ENTRER UN NOMBRE                         ####");
                    Console.WriteLine("####        DANS LLE CAS CONTRAIRE TAPER Quitter OU quitter POUR SORTIR     ####");
                    Console.WriteLine("####                   <<<< JE DIS BIEN Quitter OU quitter >>>>             ####");
                    Console.WriteLine("################################################################################");
                    Console.WriteLine("");
                    Console.WriteLine(compteur_numero + " NUMERO(S) ENTRER");
                    Console.WriteLine("");

                    Console.Write("ENTRER UN NUMERO : ");
                    valeur_entrer = Console.ReadLine();

                    if (valeur_entrer == "quitter" || valeur_entrer == "Quitter")
                    {
                        foreach (var number in nombres)
                        {
                            if (!nombres_unique.Contains(number))
                            {
                                nombres_unique.Add(number);
                            }
                        }

                        Console.WriteLine();
                        Console.Write("LES NOMBRES UNIQUES SONT :");
                        foreach (var elt in nombres_unique)
                        {
                            Console.Write(elt + " |");
                        }

                        break;
                    }
                    else
                    {
                        nombres.Add(Convert.ToInt32(valeur_entrer));
                    }
                    compteur_numero++;

                } while (valeur_entrer != "quitter" || valeur_entrer != "Quitter");
            }

            catch (Exception)
            {
                Console.WriteLine("");
                Console.WriteLine("ERREUR ??? VOUS DEVEZ ENTRER UN NUMERO OU TAPEZ q OU Q POUR QUITTER");
                Console.WriteLine("");
            }

            Console.WriteLine("");
            Console.WriteLine("");

        }
    }
}
