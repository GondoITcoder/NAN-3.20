﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_2
{
    class Program
    {
        static void Main(string[] args)
        {
            double nbre1,nbre2;

            try
            {
                Console.Write("ENTRER LE NOMBRE 1 : ");
                nbre1 = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("");

                Console.Write("ENTRER LE NOMBRE 2 : ");
                nbre2 = Convert.ToDouble(Console.ReadLine());

                if(nbre1<nbre2)
                {
                    Console.WriteLine("");
                    Console.WriteLine("LE MAXIMUM DES DEUX EST : "+nbre2);
                    Console.WriteLine("");
                }

                else if (nbre1 > nbre2)
                {
                    Console.WriteLine("");
                    Console.WriteLine("LE MAXIMUM DES DEUX EST : " + nbre1);
                    Console.WriteLine("");
                }

                else
                {
                    Console.WriteLine("");
                    Console.WriteLine("PAS DE MAXIMUM CAR : " +nbre1+" = "+nbre2);
                    Console.WriteLine("");
                }
            }

            catch (Exception)
            {
                Console.WriteLine("");
                Console.WriteLine("ERREUR ??? VOUS DEVEZ ENTRER UN NOMBRE.");
                Console.WriteLine("");
            }

        }
    }
}
