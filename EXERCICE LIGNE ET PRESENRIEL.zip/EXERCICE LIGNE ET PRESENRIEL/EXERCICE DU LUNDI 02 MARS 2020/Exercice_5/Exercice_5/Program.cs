﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_5
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> noms = new List<string>();
            string valeur_entrer;
            int nombre_de_nom = 0;

            do
            {

                Console.WriteLine("################################################################################");
                Console.WriteLine("####                    J'AI NOMMER CE PROGRAMME :                          ####");
                Console.WriteLine("####            << QUI AIME MA PUBLICATION SUR FACEBOOK >>                  ####");
                Console.WriteLine("####    ENTRER UN NOM OU APPUYEZ lA TOUCHE ENTRER OU ENTER POUR SORTIR      ####");
                Console.WriteLine("################################################################################");
                Console.WriteLine();
                Console.WriteLine(nombre_de_nom+" nom(s) ajoutee(s)");
                Console.WriteLine();

                Console.Write("ENTRER UN NOM : ");
                valeur_entrer = Console.ReadLine();

                if (String.IsNullOrWhiteSpace(valeur_entrer))
                {
                    break;
                }
                else
                {
                    noms.Add(valeur_entrer);
                }

                nombre_de_nom++;
                Console.Clear();

            } while (!String.IsNullOrWhiteSpace(valeur_entrer));

            Console.WriteLine();
            if (noms.Count == 1)
            {
                Console.WriteLine("{0}  AIME VOTRE MESSAGE.", noms[0]);
                Console.WriteLine();
            }
            else if (noms.Count == 2)
            {
                Console.WriteLine("{0} et {1} AIMENT VOTRE MESSAGE.", noms[0], noms[1]);
                Console.WriteLine();
            }
            else if (noms.Count > 2)
            {
                Console.WriteLine("{0}, {1} et {2} AUTRE(S) PERSONNE(S)  AIMENT VOTRE MESSAGE.", noms[0], noms[1], noms.Count - 2);
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine();
            }


        }
    }
}
