﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Exercice_11
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string[] mon_tableau = new string[] { };
                string fichier_text = File.ReadAllText(@"C:\gondo.txt");
                List<int> nbre_lettre_par_mot = new List<int> { };
                string mot_long;

                Console.WriteLine("");
                Console.WriteLine(fichier_text);

                Console.WriteLine("");
                mon_tableau = fichier_text.Split(' ');

                for (int i = 0; i < mon_tableau.Length; i++)
                {
                    for (int j = 0; j < mon_tableau.Length; j++)
                    {
                        do
                        {


                            nbre_lettre_par_mot.Add(Convert.ToInt32(mon_tableau[j].Length));
                            j++;
                        } while (j < mon_tableau.Length);
                    }

                    if (Convert.ToInt32(mon_tableau[i].Length) == nbre_lettre_par_mot.Max())
                    {
                        mot_long = mon_tableau[i];
                        Console.WriteLine("LE MOT LE PLUS LONG EST : " + mot_long);
                        Console.WriteLine("");
                    }
                }
            }
           catch(Exception)
            {
                Console.WriteLine("");
                Console.WriteLine("ERREUR ??? PLACER LE FICHIER TEXTE gondo.txt QUI SE TROUVE DANS LE DOSSIER Exercice_11 DANS VOTRE DISQUE C");
                Console.WriteLine("");
            }
            
        }
    }
}
