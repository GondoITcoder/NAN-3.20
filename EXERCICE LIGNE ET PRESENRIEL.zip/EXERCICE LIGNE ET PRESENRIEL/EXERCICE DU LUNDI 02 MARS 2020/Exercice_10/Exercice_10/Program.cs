﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Exercice_10
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                string[] mon_tableau = new string[] { };
                string fichier_text = File.ReadAllText(@"C:\gondo.txt");

                Console.WriteLine("");
                Console.WriteLine(fichier_text);

                Console.WriteLine("");
                mon_tableau = fichier_text.Split(' ');
                Console.WriteLine("NOMBRE DE MOT(S) : " + mon_tableau.Length);

                Console.WriteLine("");
            }
            catch (Exception)
            {
                Console.WriteLine("");
                Console.WriteLine("ERREUR ??? PLACER LE FICHIER TEXTE gondo.txt QUI SE TROUVE DANS LE DOSSIER Exercice_11 DANS VOTRE DISQUE C");
                Console.WriteLine("");
            }
        }
    }
}
